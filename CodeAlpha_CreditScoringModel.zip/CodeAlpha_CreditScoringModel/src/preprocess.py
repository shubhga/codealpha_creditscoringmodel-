"""
Data preprocessing for the Credit Scoring Model.

Loads the Statlog (German Credit Data) dataset, applies human-readable
category mappings, engineers a few extra financial-history features,
and returns a clean, model-ready DataFrame.
"""

import pandas as pd

RAW_COLUMNS = [
    "checking_account_status", "duration_months", "credit_history", "purpose",
    "credit_amount", "savings_account", "employment_since", "installment_rate_pct",
    "personal_status_sex", "other_debtors", "present_residence_since", "property",
    "age", "other_installment_plans", "housing", "existing_credits_count",
    "job", "num_dependents", "telephone", "foreign_worker", "target"
]

# Official Statlog attribute code -> human-readable label mappings
CHECKING_ACCOUNT = {
    "A11": "< 0 DM", "A12": "0 <= x < 200 DM", "A13": ">= 200 DM", "A14": "no checking account"
}
CREDIT_HISTORY = {
    "A30": "no credits taken", "A31": "all credits paid back duly",
    "A32": "existing credits paid back duly", "A33": "delay in past payments",
    "A34": "critical / other credits existing"
}
PURPOSE = {
    "A40": "car (new)", "A41": "car (used)", "A42": "furniture/equipment",
    "A43": "radio/television", "A44": "domestic appliances", "A45": "repairs",
    "A46": "education", "A47": "vacation", "A48": "retraining", "A49": "business",
    "A410": "other"
}
SAVINGS = {
    "A61": "< 100 DM", "A62": "100 <= x < 500 DM", "A63": "500 <= x < 1000 DM",
    "A64": ">= 1000 DM", "A65": "unknown / no savings account"
}
EMPLOYMENT_SINCE = {
    "A71": "unemployed", "A72": "< 1 year", "A73": "1 <= x < 4 years",
    "A74": "4 <= x < 7 years", "A75": ">= 7 years"
}
PERSONAL_STATUS_SEX = {
    "A91": "male: divorced/separated", "A92": "female: divorced/separated/married",
    "A93": "male: single", "A94": "male: married/widowed", "A95": "female: single"
}
OTHER_DEBTORS = {"A101": "none", "A102": "co-applicant", "A103": "guarantor"}
PROPERTY = {
    "A121": "real estate", "A122": "building society savings / life insurance",
    "A123": "car or other", "A124": "unknown / no property"
}
OTHER_INSTALLMENT_PLANS = {"A141": "bank", "A142": "stores", "A143": "none"}
HOUSING = {"A151": "rent", "A152": "own", "A153": "for free"}
JOB = {
    "A171": "unemployed / unskilled non-resident", "A172": "unskilled resident",
    "A173": "skilled employee/official", "A174": "management/self-employed/highly qualified"
}
TELEPHONE = {"A191": "none", "A192": "yes, registered"}
FOREIGN_WORKER = {"A201": "yes", "A202": "no"}

CATEGORY_MAPS = {
    "checking_account_status": CHECKING_ACCOUNT,
    "credit_history": CREDIT_HISTORY,
    "purpose": PURPOSE,
    "savings_account": SAVINGS,
    "employment_since": EMPLOYMENT_SINCE,
    "personal_status_sex": PERSONAL_STATUS_SEX,
    "other_debtors": OTHER_DEBTORS,
    "property": PROPERTY,
    "other_installment_plans": OTHER_INSTALLMENT_PLANS,
    "housing": HOUSING,
    "job": JOB,
    "telephone": TELEPHONE,
    "foreign_worker": FOREIGN_WORKER,
}


def load_raw(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, header=None, names=RAW_COLUMNS)
    return df


def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    for col, mapping in CATEGORY_MAPS.items():
        df[col] = df[col].map(mapping)

    # target: 1 = good credit risk, 2 = bad credit risk -> convert to 0/1
    # (1 = default / bad credit, matches "creditworthiness" framing: 1 = risky)
    df["target"] = df["target"].map({1: 0, 2: 1})  # 0 = good credit, 1 = bad credit (default risk)

    # Feature engineering from financial history
    df["debt_to_duration_ratio"] = df["credit_amount"] / df["duration_months"]
    df["is_foreign_worker"] = (df["foreign_worker"] == "yes").astype(int)
    df["has_no_checking_account"] = (df["checking_account_status"] == "no checking account").astype(int)
    df["has_critical_credit_history"] = (df["credit_history"] == "critical / other credits existing").astype(int)

    return df


def get_feature_types(df: pd.DataFrame):
    target = "target"
    numeric_features = df.drop(columns=[target]).select_dtypes(include=["int64", "float64"]).columns.tolist()
    categorical_features = df.drop(columns=[target]).select_dtypes(include=["object"]).columns.tolist()
    return numeric_features, categorical_features


if __name__ == "__main__":
    raw = load_raw("data/german_credit.csv")
    cleaned = clean(raw)
    cleaned.to_csv("data/credit_data_clean.csv", index=False)
    print(f"Cleaned dataset shape: {cleaned.shape}")
    print(f"Target distribution:\n{cleaned['target'].value_counts(normalize=True)}")
