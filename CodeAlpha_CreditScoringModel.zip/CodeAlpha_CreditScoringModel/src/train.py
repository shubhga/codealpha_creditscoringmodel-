"""
Train and compare Logistic Regression, Decision Tree, and Random Forest
classifiers for credit scoring (predicting default / bad-credit risk).

Evaluates each model on Precision, Recall, F1-Score, and ROC-AUC, then
saves the best-performing model + preprocessing pipeline to models/.
"""

import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    precision_score, recall_score, f1_score, roc_auc_score,
    roc_curve, confusion_matrix, classification_report
)

from preprocess import load_raw, clean, get_feature_types

RANDOM_STATE = 42


def build_pipeline(model, numeric_features, categorical_features):
    preprocessor = ColumnTransformer(transformers=[
        ("num", StandardScaler(), numeric_features),
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_features),
    ])
    return Pipeline(steps=[
        ("preprocessor", preprocessor),
        ("model", model),
    ])


def evaluate(name, pipeline, X_test, y_test):
    y_pred = pipeline.predict(X_test)
    y_proba = pipeline.predict_proba(X_test)[:, 1]

    metrics = {
        "model": name,
        "precision": round(precision_score(y_test, y_pred), 4),
        "recall": round(recall_score(y_test, y_pred), 4),
        "f1_score": round(f1_score(y_test, y_pred), 4),
        "roc_auc": round(roc_auc_score(y_test, y_proba), 4),
    }
    return metrics, y_pred, y_proba


def main():
    raw = load_raw("data/german_credit.csv")
    df = clean(raw)
    df.to_csv("data/credit_data_clean.csv", index=False)

    numeric_features, categorical_features = get_feature_types(df)

    X = df.drop(columns=["target"])
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_STATE, stratify=y
    )

    models = {
        "Logistic Regression": LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE),
        "Decision Tree": DecisionTreeClassifier(max_depth=6, class_weight="balanced", random_state=RANDOM_STATE),
        "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=10, class_weight="balanced", random_state=RANDOM_STATE),
    }

    results = []
    fitted_pipelines = {}
    roc_curves = {}

    for name, model in models.items():
        pipeline = build_pipeline(model, numeric_features, categorical_features)
        pipeline.fit(X_train, y_train)
        metrics, y_pred, y_proba = evaluate(name, pipeline, X_test, y_test)
        results.append(metrics)
        fitted_pipelines[name] = pipeline

        fpr, tpr, _ = roc_curve(y_test, y_proba)
        roc_curves[name] = (fpr, tpr, metrics["roc_auc"])

        print(f"\n=== {name} ===")
        print(classification_report(y_test, y_pred, target_names=["Good Credit", "Bad Credit (Default Risk)"]))
        print(f"Confusion Matrix:\n{confusion_matrix(y_test, y_pred)}")

    results_df = pd.DataFrame(results).sort_values("roc_auc", ascending=False)
    print("\n=== Model Comparison ===")
    print(results_df.to_string(index=False))

    results_df.to_csv("outputs/model_comparison.csv", index=False)
    with open("outputs/model_comparison.json", "w") as f:
        json.dump(results, f, indent=2)

    # --- Plot ROC curves ---
    plt.figure(figsize=(7, 6))
    for name, (fpr, tpr, auc) in roc_curves.items():
        plt.plot(fpr, tpr, label=f"{name} (AUC = {auc:.3f})")
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray", label="Random Baseline")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title("ROC Curves — Credit Scoring Models")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig("outputs/roc_curves.png", dpi=150)
    plt.close()

    # --- Feature importance for Random Forest ---
    rf_pipeline = fitted_pipelines["Random Forest"]
    ohe = rf_pipeline.named_steps["preprocessor"].named_transformers_["cat"]
    feature_names = numeric_features + list(ohe.get_feature_names_out(categorical_features))
    importances = rf_pipeline.named_steps["model"].feature_importances_
    fi_df = pd.DataFrame({"feature": feature_names, "importance": importances}) \
        .sort_values("importance", ascending=False).head(15)

    plt.figure(figsize=(8, 6))
    plt.barh(fi_df["feature"][::-1], fi_df["importance"][::-1], color="#2563eb")
    plt.xlabel("Importance")
    plt.title("Top 15 Feature Importances — Random Forest")
    plt.tight_layout()
    plt.savefig("outputs/feature_importance.png", dpi=150)
    plt.close()

    # --- Save best model ---
    best_name = results_df.iloc[0]["model"]
    best_pipeline = fitted_pipelines[best_name]
    joblib.dump(best_pipeline, "models/best_model.pkl")
    joblib.dump({"numeric_features": numeric_features, "categorical_features": categorical_features},
                "models/feature_schema.pkl")

    with open("models/best_model_info.json", "w") as f:
        json.dump({"best_model": best_name, "metrics": results_df.iloc[0].to_dict()}, f, indent=2)

    print(f"\nBest model: {best_name} — saved to models/best_model.pkl")


if __name__ == "__main__":
    main()
