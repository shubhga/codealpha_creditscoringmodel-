"""
Credit Scoring Model API
=========================
Serves the trained credit-risk classifier over a REST API.

Run:
    uvicorn api.main:app --reload --port 8000

Then visit http://127.0.0.1:8000/docs for interactive Swagger UI.
"""

import os
import sys
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import Literal

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODEL_PATH = os.path.join(BASE_DIR, "models", "best_model.pkl")

app = FastAPI(
    title="Credit Scoring API",
    description="Predicts an individual's credit risk (good vs. bad/default risk) from financial history.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

model = None


@app.on_event("startup")
def load_model():
    global model
    if not os.path.exists(MODEL_PATH):
        raise RuntimeError(f"Model not found at {MODEL_PATH}. Run `python src/train.py` first.")
    model = joblib.load(MODEL_PATH)


class Applicant(BaseModel):
    checking_account_status: Literal["< 0 DM", "0 <= x < 200 DM", ">= 200 DM", "no checking account"] = Field(
        ..., description="Status of existing checking account")
    duration_months: int = Field(..., ge=1, le=120, description="Loan duration in months")
    credit_history: Literal[
        "no credits taken", "all credits paid back duly", "existing credits paid back duly",
        "delay in past payments", "critical / other credits existing"
    ]
    purpose: str = Field(..., description="Purpose of the loan, e.g. 'car (new)', 'education', 'business'")
    credit_amount: float = Field(..., gt=0, description="Requested credit amount (DM)")
    savings_account: Literal[
        "< 100 DM", "100 <= x < 500 DM", "500 <= x < 1000 DM", ">= 1000 DM", "unknown / no savings account"
    ]
    employment_since: Literal["unemployed", "< 1 year", "1 <= x < 4 years", "4 <= x < 7 years", ">= 7 years"]
    installment_rate_pct: int = Field(..., ge=1, le=4, description="Installment rate as % of disposable income")
    personal_status_sex: str
    other_debtors: Literal["none", "co-applicant", "guarantor"]
    present_residence_since: int = Field(..., ge=1, le=4)
    property: str
    age: int = Field(..., ge=18, le=100)
    other_installment_plans: Literal["bank", "stores", "none"]
    housing: Literal["rent", "own", "for free"]
    existing_credits_count: int = Field(..., ge=1, le=4)
    job: str
    num_dependents: int = Field(..., ge=1, le=2)
    telephone: Literal["none", "yes, registered"]
    foreign_worker: Literal["yes", "no"]

    class Config:
        json_schema_extra = {
            "example": {
                "checking_account_status": "< 0 DM",
                "duration_months": 24,
                "credit_history": "existing credits paid back duly",
                "purpose": "car (new)",
                "credit_amount": 4500,
                "savings_account": "< 100 DM",
                "employment_since": "1 <= x < 4 years",
                "installment_rate_pct": 3,
                "personal_status_sex": "male: single",
                "other_debtors": "none",
                "present_residence_since": 2,
                "property": "car or other",
                "age": 29,
                "other_installment_plans": "none",
                "housing": "own",
                "existing_credits_count": 1,
                "job": "skilled employee/official",
                "num_dependents": 1,
                "telephone": "yes, registered",
                "foreign_worker": "yes",
            }
        }


def engineer_features(applicant: Applicant) -> pd.DataFrame:
    row = applicant.dict()
    row["debt_to_duration_ratio"] = row["credit_amount"] / row["duration_months"]
    row["is_foreign_worker"] = 1 if row["foreign_worker"] == "yes" else 0
    row["has_no_checking_account"] = 1 if row["checking_account_status"] == "no checking account" else 0
    row["has_critical_credit_history"] = 1 if row["credit_history"] == "critical / other credits existing" else 0
    return pd.DataFrame([row])


@app.get("/")
def root():
    return {"status": "ok", "message": "Credit Scoring API is running. Visit /docs for the interactive UI."}


@app.get("/health")
def health():
    return {"status": "healthy", "model_loaded": model is not None}


@app.post("/predict")
def predict(applicant: Applicant):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    X = engineer_features(applicant)
    proba_bad = float(model.predict_proba(X)[0, 1])
    prediction = int(model.predict(X)[0])

    if proba_bad < 0.3:
        risk_band = "Low Risk"
    elif proba_bad < 0.6:
        risk_band = "Medium Risk"
    else:
        risk_band = "High Risk"

    return {
        "prediction": "Bad Credit / Default Risk" if prediction == 1 else "Good Credit",
        "default_probability": round(proba_bad, 4),
        "risk_band": risk_band,
    }
